#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from enum import Enum
import json
from copy import copy
from SkyminerTS.Utils.BadTypeException import BadTypeException


class SkyminerStr(str):
    """
    Overrides the str object of Python and adds the method object() which makes it easy to transform a json into a python
    object.
    """

    def __new__(cls, value, *args, **kwargs):
        return super(SkyminerStr, cls).__new__(cls, value)

    def object(self):
        return json.loads(self.__str__())


def json_encoder(obj):
    """
    Json encoder for nested dictionaries
    """
    if hasattr(obj, '__dict__'):
        return obj.dict()
    else:
        return obj


class Generic:
    """
    Inherit from this class if you don't want empty elements in your dictionary.
    """

    def dict(self):
        return {k: v for k, v in self.__dict__.items() if v != None and v != [] and v != {}}

    def json(self):
        return json.dumps(self.dict())


class GenericBuilder(Generic):
    """
    Basic json builder with nested dictionaries management.
    """

    def build(self):
        """
        Transform a python class into a json string

        :return: A json string which contains the attributes of the class
        """
        builder = self._build(self)
        return json.dumps(builder, default=json_encoder)

    def _build(self, obj=None):
        copy_obj = copy(obj)
        data = {}
        if isinstance(copy_obj, list):
            return [self._build(x) for x in copy_obj]
        else:
            if hasattr(obj, '__dict__'):
                for k, v in copy_obj.dict().items():
                    try:
                        data[k] = self._build(v)
                    except:
                        data[k] = json.dumps(v)
            else:
                return obj
        return data


def check_instance(ins, cls):
    """
    Checks if the instance of a class matches a given class

    :param ins: Instance of a class
    :param cls: The compared class
    :return: Is the object an instance of the class
    """
    if not isinstance(ins, cls):
        raise BadTypeException(ins, cls)
    return True


def type_safe_copy(ins, cls):
    """
    Check if the instance of a class matches a given class before a copy

    :param ins: Instance of the object
    :param cls:  The compared class
    :return: Copy of the instance of the class if the instance of the class matches the given class
    """
    check_instance(ins, cls)
    return copy(ins)


class TimeUnit(Enum):
    MILLISECONDS = 'milliseconds'
    SECONDS = 'seconds'
    MINUTES = 'minutes'
    HOURS = 'hours'
    DAYS = 'days'
    WEEKS = 'weeks'
    MONTHS = 'months'
    YEARS = 'years'


class QueryDataOrder(Enum):
    ASC = 'asc'
    DESC = 'desc'


def merge_array(array_1, array_2):
    """
    Merge two arrays into a new array

    :param array_1: first array
    :param array_2: second array
    :return: Return the new merged array
    """
    n_array = copy(array_1)
    for v in array_2:
        n_array.append(v)
    return n_array
