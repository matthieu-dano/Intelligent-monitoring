import pandas as pd
import numpy as np

from SkyminerTS.DataPoint import DataPointBuilder
from SkyminerTS.Utils.Utils import merge_array
from io import BytesIO
import json

def CsvToDataframe(csv_data_bytes):
    """
    Transform Skyminer Csv query results into Dataframe

    :param raw_queries: Skyminer Csv query results
    :return: Dataframe
    """
    # Convert bytes to csv
    csv = BytesIO(csv_data_bytes)
    # Convert csv to dataframe
    dataframe = pd.read_csv(csv)
    return dataframe


def __autocompute_aliases(raw_queries):
    """
    Generates aliases for a list of queries.
    
    :param raw_queries: Skyminer query results
    :return: List
    """
    aliases = list()
    for query in raw_queries["queries"]:
        aliases.append(query['results'][0]['name'])      
    # Find the duplicated aliases
    duplicated = pd.Series(aliases).duplicated(keep=False)
    # Create a dictionary to keep track of the count for each unique name
    count_dict = dict([(key, 1) for key in aliases])
    # Loop through the aliases and add a unique identifier to each duplicate
    for i in range(len(aliases)):
        if duplicated[i]:
            metric_name=aliases[i]
            aliases[i] = f"{metric_name}_{count_dict[metric_name]}"
            count_dict[metric_name] += 1
        else:
            continue
    return aliases


def QueriesToDataframe(raw_queries):
    """
    Transform Skyminer query results into Dataframe

    :param raw_queries: Skyminer query results
    :return: Dataframe
    """
    list_dataframes = []
    aliases = __autocompute_aliases(raw_queries)


    for index, query in enumerate(raw_queries["queries"]):
        list_dataframes.append(QueryToDataframe(query, alias=aliases[index] if len(aliases) > 0 else None))
    dataframe = pd.concat(list_dataframes, sort=False)
    if 'timestamp' in dataframe:
        dataframe["date"] = pd.to_datetime(dataframe['timestamp'], unit='ms')
        dataframe.set_index("date", inplace=True)
    return dataframe.astype(object).replace(np.nan, "")


def QueryToDataframe(raw_query, alias=None):
    """
    Transform  Skyminer Query result into a Dataframe

    :param raw_query: Skyminer query results
    :return: Dataframe
    """
    data = []
    tags_name = []
    for query in raw_query["results"]:
        tags_name.extend(tag for tag in list(query['tags'].keys()) if tag not in tags_name)
        current_series_tags_name = list(query['tags'].keys())
        groupby = {}
        if "group_by" in query:
            for group in query["group_by"]:
                if "group" in group:
                    if "group_by" not in tags_name:
                        tags_name.append("group_by")
                    groupby = {**groupby, **{group["name"]: group["group"]}}
        if "values" in query:
            for value in query["values"]:
                new_values = list(query["tags"].values())
                if groupby != {}:
                    new_values.append(groupby)
                    current_series_tags_name.append('group_by')
                """
                This part needs to be added to correct for a potential bias if a new tag appears, 
                which could cause a mismatch.
                """
                corrected_values = []
                for name in tags_name:
                    if name in current_series_tags_name:
                        tag_index = current_series_tags_name.index(name)
                        corresponding_value = new_values[tag_index]
                    else:
                        corresponding_value = None
                    corrected_values.append(corresponding_value)
                data.append(merge_array([value[0]] +
                                        [alias if alias is not None else query["name"]] +
                                        [value[1]], corrected_values))
    dataframe_columns = ['timestamp', 'metricname', 'value']
    if not data:
        df = pd.DataFrame(columns=dataframe_columns)
    else:
        df = pd.DataFrame(data, columns=merge_array(dataframe_columns, tags_name))
    return df.astype(object).replace(np.nan, "")


def DataFrameToDataPointBuilder(dataframe, metric_name, value_field='value', tags={}):
    """
    Convert a Dataframe into a DataPointBuilder

    :param dataframe: The Dataframe
    :param metric_name: The name of the metric
    :param value_field: The name of the column which contains the values of the metric
    :param tags: A dictionnary of tags you want to attach to the metric
    :return: The DataPointBuilder
    """
    datapoints = [[int(x.timestamp() * 1000), y] for x, y in zip(dataframe.index, dataframe[value_field])]
    return DataPointBuilder(metric_name, datapoints, tags)


def MetricToDataframe(server_url, metric, start, end, filters, alias):
    """
    Request a timeserie to Skyminer and return the result in Dataframe

    :param server_url: Url of the Skyminer, must be formated like this: http://skyminer.domain
    :param metric: Name of the metric
    :param start: The time of the first sample in epoch millisecond
    :param end: The time of the last sample in epoch millisecond
    :param filters: Dictionnary of tags to filter
    :param alias: Optional: Alias of the metric
    :return: A Dataframe
    """
    skyminer_query = """
        {
          "metrics": [
            {
              "name": "%s",
              "tags": %s
            }
          ],
          "start_absolute": %i,
          "end_absolute": %i

        }
        """ % (metric, json.dumps(filters), start, end)
    from SkyminerTS.SkyminerTSPythonConnector import API as STSAPI
    skyminerAPI = STSAPI.init(server_url + "/api/v1")
    queryResult = skyminerAPI.get_data_points(skyminer_query)

    # Update metric name
    new_name = metric
    if alias:
        new_name = alias
    elif filters: # Add filters to the metric name
        new_name += ": "
        for filter in filters:
            new_name += "%s=%s " % (filter, str(filters[filter]))
    queryResult['queries'][0]['results'][0].update({'name': new_name})
    return QueriesToDataframe(queryResult)
