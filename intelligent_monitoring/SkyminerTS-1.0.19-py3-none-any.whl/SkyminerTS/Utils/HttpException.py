#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from copy import copy


class HttpException(Exception):
    def __init__(self, message, url=None):
        copy_url = copy(url)
        Exception.__init__(self, '%s %s' % (copy_url if copy_url is not None else '', message))


def errors():
    return ['400', '403', '404', '500']


def check(http_code, data, url=None):
    if str(http_code) in errors():
        raise HttpException(data, copy(url))
