#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'


class BadTypeException(Exception):
    def __init__(self, ins, cls):
        super(BadTypeException, self).__init__(
            "Bad type " + type(ins).__name__ + " where " + cls.__name__ + " expected")
