#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Utils import Generic


class GroupBy(Generic):
    """
    This class is used for the construction of other GroupBy Objects

    :param str name: Name of the group by
    """
    def __init__(self, name):
        self.name = name
