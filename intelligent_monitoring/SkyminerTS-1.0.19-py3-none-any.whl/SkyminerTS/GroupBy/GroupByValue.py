#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.GroupBy import GroupBy
from copy import copy


class GroupByValue(GroupBy):
    """
    GroupBy Value object

    :param int range_size: The range size, default=0
    """
    def __init__(self, range_size=0):
        super(GroupByValue, self).__init__('value')
        self.with_range_size(range_size)

    def with_range_size(self, range_size):
        """
        Set the range size

        :param range_size: The range size
        :raise: range_size can't be negative
        :return: Instance of the groupby
        :rtype: GroupByValue
        """
        if range_size < 0:
            raise Exception('range_size can\'t be negative.')
        self.range_size = range_size
        return self
