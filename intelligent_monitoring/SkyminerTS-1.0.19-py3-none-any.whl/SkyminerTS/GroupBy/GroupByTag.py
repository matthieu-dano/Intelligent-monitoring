#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.GroupBy import GroupBy
from copy import copy
from SkyminerTS.Utils import type_safe_copy


class GroupByTag(GroupBy):
    """
    GroupBy Tag Object

    :param List[str] tags: List of tags, optional, default: []

    """

    def __init__(self, tags=[]):
        super(GroupByTag, self).__init__('tag')
        self.tags = type_safe_copy(tags, list)

    def with_tag(self, tag):
        """
        Add a tag

        :param str tag: The tag
        :return: Instance of the groupby
        :rtype: GroupByTag
        """
        self.tags.append(tag)
        return self

    def with_tags(self, tags):
        """
        Add tags

        :param list[str] tags: List of tags
        :return: Instance of the groupby
        :rtype: GroupByTag
        """
        self.tags.extend(tags)
        return self

