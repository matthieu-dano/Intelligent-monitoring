#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Utils import TimeUnit, type_safe_copy
from SkyminerTS.GroupBy import GroupBy
from copy import copy


class GroupByTime(GroupBy):
    """
    GroupBy Time object

    :param group_count: group count, optional, default: None
    :param value: Value of the time unit, optional, default: None
    :param unit: Unit of the time (instance of the enum TimeUnit), default: None
    """
    def __init__(self, group_count=None, value=None, unit=None):
        super(GroupByTime, self).__init__('time')
        self.group_count = copy(group_count)
        tunit = type_safe_copy(unit, TimeUnit)
        self.range_size = {'value': copy(value), 'unit': tunit.value}

    def with_group_count(self, group_count):
        """
        Set the group count
        :param group_count: The group count
        :return: Instance of the groupby
        :rtype: GroupByTime
        """
        self.group_count = group_count
        return self

    def with_value(self, value):
        """
        Set the value of the time
        :param value: Value of the time
        :return: Instance of the groupby
        :rtype: GroupByTime
        """
        self.range_size['value'] = value
        return self

    def with_unit(self, unit):
        """
        Set the unit of time
        :param unit: Unit of time (instance of the enum TimeUnit)
        :return: Instance of the groupby
        :rtype: GroupByTime
        """
        tunit = type_safe_copy(unit, TimeUnit)
        self.range_size['unit'] = tunit.value
        return self
