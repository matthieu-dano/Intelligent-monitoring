#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.GroupBy import GroupBy
from copy import copy
from SkyminerTS.Utils import type_safe_copy


class GroupByBin(GroupBy):
    """
    GroupBy Bin Object

    :param bins: List of bins, optional
    """
    def __init__(self, bins=[]):
        super(GroupByBin, self).__init__('bin')
        self.bins = type_safe_copy(bins, list)

    def with_bin(self, bin):
        """
        Add a bin

        :param bin: The bin
        :return: Instance of the groupby
        """
        self.bins.append(bin)
        return self

    def with_bins(self, bins):
        """
        Add bins

        :param bins: List of bin
        :return: Instance of the groupby
        """
        self.bin.extends(bins)
        return self
