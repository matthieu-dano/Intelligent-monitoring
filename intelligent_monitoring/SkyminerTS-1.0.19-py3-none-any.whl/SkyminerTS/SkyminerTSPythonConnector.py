#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
import httplib2
import json
from SkyminerTS.Utils import SkyminerStr
from SkyminerTS.Utils.HttpException import check


class API:
    _SERVER = None
    _CHARSET = None
    _http = None

    @staticmethod
    def init(url, charset='utf-8', timeout_ms=100, disable_ssl_certificate_validation=True, ca_certs=None):
        """
        Initializes the API.\n

        :param url: The url of the API
        :param charset: The charset to decode data (default : utf-8)
        :param timeout_ms: Connection timeout in ms (default: 100)
        :param disable_ssl_certificate_validation: Disable ssl (default: True)
        :return: The API
        """
        api = API()
        api._CHARSET = charset
        api._SERVER = url
        if ca_certs is None:
            api._http = httplib2.Http(timeout=timeout_ms,
                                      disable_ssl_certificate_validation=disable_ssl_certificate_validation)
        else:
            api._http = httplib2.Http(timeout=timeout_ms,
                                      disable_ssl_certificate_validation=disable_ssl_certificate_validation,
                                      ca_certs=ca_certs)

        return api

    ######################################
    #                                    #
    #              GENERICS              #
    #                                    #
    ######################################

    def _decode(self, string):
        """
        Transforms a json in python object

        :param string: the json.
        :return: the pyhon object
        """
        return SkyminerStr(string.decode(self._CHARSET)).object()

    def _url(self, path):
        """
        Concatenates the url of the API with a path.\n

        :param path: The path
        :return: The path concatenated with the url of the API
        """
        return str(self._SERVER) + str(path)

    def skyminer_url(self, path):
        """
        Concatenates the url of the API with a path,
        replaces the trailing /v1 from the server URL by /skyminer.\n

        :param path: The path
        :return: The path concatenated with the url of the API, 
        """
        return str(self._SERVER)[:-2] + 'skyminer' + str(path)
        
    def _get(self, url, token=None):
        """
        Get method.\n

        :param url: url
        :param token: Bearer token used to authenticate the request - Optional
        :return: API's response
        """
        result = self.request(uri=url, method='GET', token=token)
        check(result[0]['status'], result, url)
        return result

    def _get_data(self, url, token=None):
        """
        Return the body of the get method decoded with the charset of the API.\n

        :param url: url
        :param token: Bearer token used to authenticate the request - Optional
        :return: The body of the get method
        """
        result = self._get(url, token)
        return self._decode(result[1])

    def _head(self, url, token=None):
        """
        Head method.\n

        Return only the request headers
        :param url: url
        :param token: Bearer token used to authenticate the request - Optional
        :return: The request headers
        """
        result = self.request(uri=url, method='HEAD', token=token)
        check(result[0]['status'], result, url)
        return result

    def _post(self, url, data, token=None):
        """
        Post method.\n
        The data parameter need to be an object.

        :param url: url
        :param data: Simple python object
        :param token: Bearer token used to authenticate the request - Optional
        :return: API's response
        """
        try:
            result = self.request(
                uri=url,
                method='POST',
                headers={'Content-Type': 'application/json'},
                body=data,
                token=token
            )
        except BrokenPipeError as e:
            # Retry if BrokenPipe exception
            result = self.request(
                uri=url,
                method='POST',
                headers={'Content-Type': 'application/json'},
                body=data,
                token=token
            )
        check(result[0]['status'], result, url)
        return result

    def _put(self, url, data, token=None):
        """
        Put method.\n
        The data parameter need to be an object.\n

        :param url: url
        :param data: Simple python object
        :param token: Bearer token used to authenticate the request - Optional
        :return: API's response
        """
        result = self.request(
            uri=url,
            method='PUT',
            headers={'Content-Type': 'application/json charset=UTF-8'},
            body=json.dumps(data),
            token=token
        )
        check(result[0]['status'], result, url)
        return result

    def _delete(self, url, token=None):
        """
        Delete method.\n

        :param url: url
        :param token: Bearer token used to authenticate the request - Optional
        :return: API's response
        """
        result = self.request(uri=url, method='DELETE', token=token)
        check(result[0]['status'], result, url)
        return result

    ######################################
    #                                    #
    #               KAIROS               #
    #                                    #
    ######################################

    def get_data_points(self, query, file_format='JSON', token=None):
        """
        Get data points from database in the chosen format.

        :param query: Skyminer Queries
        :param file_format: str, default='JSON'.
            The possibilities are:
            - 'JSON'
            - 'CSV_ONE_ROW_PER_TIMESTAMP'
            - 'CSV_ONE_ROW_PER_VALUE'
            - 'CSV_ONE_ROW_PER_VALUE_DETAILED'
        :param token: Bearer token used to authenticate the request - Optional
        """
        valid_formats = ['JSON',
                         'CSV_ONE_ROW_PER_TIMESTAMP',
                         'CSV_ONE_ROW_PER_VALUE',
                         'CSV_ONE_ROW_PER_VALUE_DETAILED']

        if (file_format not in valid_formats):
            raise ValueError("Unknown format %s. "
                             "Valid formats are %s" % (file_format, valid_formats))

        if file_format == 'JSON':
            return self._decode(
                self._post(self._url('/datapoints/query'), query, token)[1])
        elif file_format == 'CSV_ONE_ROW_PER_TIMESTAMP':
            return self._post(
                self.skyminer_url('/query_csv/one_row_per_timestamp'), query, token)[1]
        elif file_format == 'CSV_ONE_ROW_PER_VALUE':
            return self._post(
                self.skyminer_url('/query_csv/one_row_per_value'), query, token)[1]
        elif file_format == 'CSV_ONE_ROW_PER_VALUE_DETAILED':
            return self._post(
                self.skyminer_url('/query_csv/one_row_per_value_detailed'), query, token)[1]

    def get_data_points_tags(self, query, token=None):
        return self._decode(self._post(self._url('/datapoints/query/tags'), query, token)[1])

    def get_metrics(self, prefix=None, token=None):
        path = '/metricnames'
        if prefix is not None:
            path += '?prefix=' + prefix
        return self._get_data(self._url(path), token)['results']

    def query_metrics_data(self, query, token=None):
        return self._post(self._url('/query'), query, token)

    def query_metric_tags(self, query, token=None):
        return self._post(self._url('/datapoints/query/tags'), query, token)

    def add_data_points(self, query, token=None):
        return self._post(self._url('/datapoints'), query, token)

    def delete_data_points(self, query, token=None):
        return self._post(self._url('/datapoints/delete'), query, token)

    def delete_metric(self, name, token=None):
        return self._delete(self._url(f"/metric/{name}"), token)

    def request(self, uri, method="GET", body=None, headers=None, token=None):
        if token is not None:
            if headers is None:
                headers = {}
            headers['Authorization'] = f"Bearer {token}"
        return self._http.request(
            uri=uri,
            method=method,
            headers=headers,
            body=body,
        )
