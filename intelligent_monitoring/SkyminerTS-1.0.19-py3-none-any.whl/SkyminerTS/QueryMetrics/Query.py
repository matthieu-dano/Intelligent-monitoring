#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Utils import GenericBuilder, check_instance, type_safe_copy
from SkyminerTS.QueryMetrics.Metric import MetricBuilder
from SkyminerTS.QueryMetrics.TimeRelative import TimeRelative
from copy import copy


class QueryBuilder(GenericBuilder):
    """
    Build a Query that will be send to Skyminer

    Information:
    You cannot use start absolute and start relative or stop absolute and stop relative at the same time.

    :param int start_absolute: start relative of the query, default: None
    :param TimeRelative start_relative: start relative of the query, default: None
    :param int end_absolute: stop relative of the query, default: None
    :param TimeRelative end_relative: stop relative of the query, default: None
    :param str time_zone: time zone of the request, default: None
    :param list[MetricBuilder] metrics: list of Metrics you want to query, default: []
    """

    def __init__(self, start_absolute=None, start_relative=None, end_absolute=None, end_relative=None, time_zone=None,
                 metrics=[]):
        self.start_absolute = copy(start_absolute)
        self.start_relative = copy(start_relative)
        self.end_absolute = copy(end_absolute)
        self.end_relative = copy(end_relative)
        self.time_zone = copy(time_zone)
        self.metrics = type_safe_copy(metrics, list)

    def with_start_absolute(self, start_absolute):
        """
        Set the start absolute of the query

        Information:
        Cannot be used with start relative.

        :param int start_absolute: start absolute of the query
        :return: QueryBuilder instance
        :rtype: QueryBuilder
        """
        self.start_absolute = start_absolute
        return self

    def with_start_relative(self, value, unit):
        """
        Set the start relative of the query

        Information:
        Cannot be used with start absolute.

        :param int value: quantity of time
        :param: TimeUnit unit: unity of time
        :return: QueryBuilder instance
        :rtype: QueryBuilder
        """
        self.start_relative = TimeRelative(value, unit)
        return self

    def with_end_absolute(self, end_absolute):
        """
        Set the end absolute of the query

        Information:
        Cannot be used with end relative.

        :param int end_absolute: end absolute of the query
        :return: QueryBuilder instance
        :rtype: QueryBuilder
        """
        self.end_absolute = end_absolute
        return self

    def with_end_relative(self, value, unit):
        """
        Set the end relative of the query

        Information:
        Cannot be used with end absolute.

        :param int value: quantity of time
        :param: TimeUnit unit: unity of time
        :return: QueryBuilder instance
        :rtype: QueryBuilder
        """
        self.end_relative = TimeRelative(value, unit)
        return self

    def with_time_zone(self, timezone):
        """
        Set the timezone of the query

        :param timezone: Timezone of the query
        :return: QueryBuilder instance
        :rtype: QueryBuilder
        """
        self.time_zone = timezone
        return self

    def with_metrics(self, metrics):
        """
        Set the metrics of the query

        :param list[MetricBuilder] metrics: list of MetricBuilder
        :return: QueryBuilder instance
        :rtype: QueryBuilder
        """
        self.metrics = metrics
        return self

    def with_metric(self, metric):
        """
        Add a metric to the query

        :param MetricBuilder metric: MetricBuilder
        :return: QueryBuilder instance
        :rtype: QueryBuilder
        """
        check_instance(metric, MetricBuilder)
        self.metrics.append(metric)
        return self
