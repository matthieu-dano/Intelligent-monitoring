#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Utils import Generic, TimeUnit, check_instance


class TimeRelative(Generic):
    """
    Build a TimeRelative Object for the QueryBuilder class

    :param int value: Value of the time
    :param TimeUnit unit: Time unit (instance of the enum TimeUnit)
    """
    def __init__(self, value, unit):
        self.value = value
        check_instance(unit, TimeUnit)
        self.unit = unit.value

    def build(self):
        return self.dict()
