#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Utils import Generic, QueryDataOrder, type_safe_copy, check_instance
from copy import copy


class MetricBuilder(Generic):
    """
    Helper that builds a metric that will be searched in Skyminer

    :param str name: Name of the metric
    :param list[Aggregator] aggregators: List of aggregators, optional, default: []
    :param Dict[str,str] tags: Dictionnary of tags to filter, optional, default: dict()
    :param list[GroupBy] group_by: List of group by, optional, default=[]
    :param bool exclude_tags: Exclude tags, optional, default: False
    :param int limit: Limit of point for the request, optional, default: None
    :param QueryDataOrder order: Data return order, optional, default: QueryDataOrder.ASC
    """

    def __init__(self, name, aggregators=[], tags={}, group_by=[], exclude_tags=False, limit=None,
                 order=QueryDataOrder.ASC):

        self.name = name
        self.aggregators = type_safe_copy(aggregators, list)
        self.tags = type_safe_copy(tags, dict)
        self.group_by = type_safe_copy(group_by, list)
        self.exclude_tags = copy(exclude_tags)
        self.limit = copy(limit)
        self.order = copy(order.value)

    def with_aggregator(self, aggregator):
        """
        Add an aggregator

        :param Aggregator: The aggregator
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        self.aggregators.append(aggregator)
        return self

    def with_aggregators(self, aggregators):
        """
        Add multiple aggregators

        :param list[Aggregator] aggregators: List of aggregators
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        self.aggregators.extend(aggregators)
        return self

    def with_tag_filter(self, key, value):
        """
        Add tag to filter

        :param str key: Name of the tag
        :param str value: Value of the tag
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        self.tags[key] = value
        return self

    def with_tags_filter(self, tags):
        """
        Add tags to filter

        :param tags: Dictionnary of tags {tag_name: value}
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        self.tags = dict(self.tags, **tags)
        return self

    def exclude_tags(self, boolean=True):
        """
        Set the value of the flag that excludes tags

        :param bool boolean: Value of the flag, default: true
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        self.exclude_tags = boolean
        return self

    def with_limit(self, limit):
        """
        Set the limit of the request

        :param int limit: The limit
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        self.limit = limit
        return self

    def with_order(self, order):
        """
        Set the return order of the data

        :param QueryDataOrder order: Order of the data (must be an instance of the enum QueryDataOrder)
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        check_instance(order, QueryDataOrder)
        self.order = order.value
        return self

    def with_group_by(self, group_by):
        """
        Add a group-by

        :param GroupBy group_by: The group by object
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        self.group_by.append(group_by)
        return self

    def with_group_bys(self, group_bys):
        """
        Add multiple group-by

        :param list[GroupBy] group_by: A list of group by object
        :return: The instance of the builder
        :rtype: MetricBuilder
        """
        self.group_by.extend(group_bys)
        return self

