#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class JsFilterAggregator(Aggregator):
    name = None
    script = None 

    def __init__(self, script=None):
        self.name = 'js_filter'
        self.script = copy(script)

    def with_script(self, script):
        self.script = script
        return self

