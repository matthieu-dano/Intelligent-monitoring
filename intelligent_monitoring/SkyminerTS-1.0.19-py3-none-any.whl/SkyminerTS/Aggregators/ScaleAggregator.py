#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class ScaleAggregator(Aggregator):
    name = None
    factor = None 

    def __init__(self, factor=0.0):
        self.name = 'scale'
        self.factor = copy(factor)

    def with_factor(self, factor):
        self.factor = factor
        return self

