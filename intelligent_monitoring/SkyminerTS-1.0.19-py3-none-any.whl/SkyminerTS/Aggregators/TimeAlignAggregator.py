#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy
from enum import Enum

class Method(Enum):
     OVERRIDDEN_START_TIME='overridden_start_time'
     OVERRIDDEN_END_TIME='overridden_end_time'
     DATA_TO_QUERY_START_TIME='data_to_query_start_time'
     DATA_TO_START_OF_MINUTE='data_to_start_of_minute'
     DATA_TO_START_OF_HOUR='data_to_start_of_hour'
     DATA_TO_START_OF_DAY='data_to_start_of_day'
     DATA_TO_START_OF_WEEK='data_to_start_of_week'
     DATA_TO_START_OF_MONTH='data_to_start_of_month'
     DATA_TO_START_OF_YEAR='data_to_start_of_year'


class TimeAlignAggregator(Aggregator):
    name = None
    align_to_calendar_unit_only = None 
    reference_end_time = None 
    reference_start_time = None 
    method = None 
    time_zone = None 

    def __init__(self, align_to_calendar_unit_only=True, reference_end_time=0, reference_start_time=0, method=Method.OVERRIDDEN_START_TIME, time_zone=None):
        self.name = 'time_align'
        self.align_to_calendar_unit_only = copy(align_to_calendar_unit_only)
        self.reference_end_time = copy(reference_end_time)
        self.reference_start_time = copy(reference_start_time)
        self.method = copy(method)
        self.time_zone = copy(time_zone)

    def with_align_to_calendar_unit_only(self, align_to_calendar_unit_only):
        self.align_to_calendar_unit_only = align_to_calendar_unit_only
        return self

    def with_reference_end_time(self, reference_end_time):
        self.reference_end_time = reference_end_time
        return self

    def with_reference_start_time(self, reference_start_time):
        self.reference_start_time = reference_start_time
        return self

    def with_method(self, method):
        self.method = method
        return self

    def with_time_zone(self, time_zone):
        self.time_zone = time_zone
        return self

