#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy
from enum import Enum

class Order(Enum):
     ASCENDING='ascending'
     DESCENDING='descending'


class ScoreAggregator(Aggregator):
    name = None
    order = None 
    thresholds = None 

    def __init__(self, order=Order.ASCENDING, thresholds=None):
        self.name = 'score'
        self.order = copy(order)
        self.thresholds = copy(thresholds)

    def with_order(self, order):
        self.order = order
        return self

    def with_thresholds(self, thresholds):
        self.thresholds = thresholds
        return self

