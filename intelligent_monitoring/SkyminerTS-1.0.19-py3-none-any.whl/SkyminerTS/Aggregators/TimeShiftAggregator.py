#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy
from enum import Enum

class Direction(Enum):
     SHIFT_FORWARD='shift_forward'
     SHIFT_BACKWARD='shift_backward'


class TimeShiftAggregator(Aggregator):
    name = None
    direction = None 
    sampling = None 

    def __init__(self, direction=Direction.SHIFT_FORWARD, sampling=None):
        self.name = 'time_shift'
        self.direction = copy(direction)
        self.sampling = copy(sampling)

    def with_direction(self, direction):
        self.direction = direction
        return self

    def with_sampling(self, sampling):
        self.sampling = sampling
        return self

