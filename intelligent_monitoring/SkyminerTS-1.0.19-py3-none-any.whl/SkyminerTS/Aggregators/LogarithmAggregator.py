#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class LogarithmAggregator(Aggregator):
    name = None
    exponent = None 

    def __init__(self, exponent=None):
        self.name = 'log'
        self.exponent = copy(exponent)

    def with_exponent(self, exponent):
        self.exponent = exponent
        return self

