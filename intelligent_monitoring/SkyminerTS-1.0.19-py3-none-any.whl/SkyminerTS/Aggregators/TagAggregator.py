#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class TagAggregator(Aggregator):
    name = None
    tag_name = None 
    tag_value = None 

    def __init__(self, tag_name=None, tag_value=None):
        self.name = 'tag'
        self.tag_name = copy(tag_name)
        self.tag_value = copy(tag_value)

    def with_tag_name(self, tag_name):
        self.tag_name = tag_name
        return self

    def with_tag_value(self, tag_value):
        self.tag_value = tag_value
        return self

