#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class DivAggregator(Aggregator):
    name = None
    divisor = None 

    def __init__(self, divisor=1.0):
        self.name = 'div'
        self.divisor = copy(divisor)

    def with_divisor(self, divisor):
        self.divisor = divisor
        return self

