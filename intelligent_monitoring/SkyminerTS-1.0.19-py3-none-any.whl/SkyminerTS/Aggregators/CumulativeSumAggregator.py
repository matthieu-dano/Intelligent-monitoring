#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class CumulativeSumAggregator(Aggregator):
    name = None
    start_at_zero = None 

    def __init__(self, start_at_zero=True):
        self.name = 'cumsum'
        self.start_at_zero = copy(start_at_zero)

    def with_start_at_zero(self, start_at_zero):
        self.start_at_zero = start_at_zero
        return self

