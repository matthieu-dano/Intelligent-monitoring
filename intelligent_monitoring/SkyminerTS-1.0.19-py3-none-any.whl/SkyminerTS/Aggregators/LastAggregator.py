#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class LastAggregator(Aggregator):
    name = None
    align_end_time = None 
    align_start_time = None 
    sampling = None 
    trim = None 

    def __init__(self, align_end_time=True, align_start_time=True, sampling=None, trim=True):
        self.name = 'last'
        self.align_end_time = copy(align_end_time)
        self.align_start_time = copy(align_start_time)
        self.sampling = copy(sampling)
        self.trim = copy(trim)

    def with_align_end_time(self, align_end_time):
        self.align_end_time = align_end_time
        return self

    def with_align_start_time(self, align_start_time):
        self.align_start_time = align_start_time
        return self

    def with_sampling(self, sampling):
        self.sampling = sampling
        return self

    def with_trim(self, trim):
        self.trim = trim
        return self

