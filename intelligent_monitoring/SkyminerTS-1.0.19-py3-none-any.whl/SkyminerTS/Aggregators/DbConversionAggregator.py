#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy
from enum import Enum

class Invalid_Value_Strategy(Enum):
     FAIL_ON_INVALID_VALUES='fail_on_invalid_values'
     SKIP_INVALID_VALUES='skip_invalid_values'
     REPLACE_INVALID_VALUES_BY_CONSTANT='replace_invalid_values_by_constant'

class Conversion(Enum):
     DB_TO_LINEAR='db_to_linear'
     LINEAR_TO_DB='linear_to_db'


class DbConversionAggregator(Aggregator):
    name = None
    invalid_value_strategy = None 
    invalid_value_replacement_constant = None 
    conversion = None 

    def __init__(self, invalid_value_strategy=Invalid_Value_Strategy.FAIL_ON_INVALID_VALUES, invalid_value_replacement_constant=1.0, conversion=Conversion.DB_TO_LINEAR):
        self.name = 'dB_conversion'
        self.invalid_value_strategy = copy(invalid_value_strategy)
        self.invalid_value_replacement_constant = copy(invalid_value_replacement_constant)
        self.conversion = copy(conversion)

    def with_invalid_value_strategy(self, invalid_value_strategy):
        self.invalid_value_strategy = invalid_value_strategy
        return self

    def with_invalid_value_replacement_constant(self, invalid_value_replacement_constant):
        self.invalid_value_replacement_constant = invalid_value_replacement_constant
        return self

    def with_conversion(self, conversion):
        self.conversion = conversion
        return self

