#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy
from enum import Enum

class Time_Align(Enum):
     ALIGN_START_TIME='align_start_time'
     ALIGN_END_TIME='align_end_time'
     ALIGN_SAMPLING='align_sampling'
     NO_ALIGN='no_align'


class DownsampleAggregator(Aggregator):
    name = None
    time_align = None 
    nb_samples = None 

    def __init__(self, time_align=Time_Align.ALIGN_SAMPLING, nb_samples=2000):
        self.name = 'downsample'
        self.time_align = copy(time_align)
        self.nb_samples = copy(nb_samples)

    def with_time_align(self, time_align):
        self.time_align = time_align
        return self

    def with_nb_samples(self, nb_samples):
        self.nb_samples = nb_samples
        return self

