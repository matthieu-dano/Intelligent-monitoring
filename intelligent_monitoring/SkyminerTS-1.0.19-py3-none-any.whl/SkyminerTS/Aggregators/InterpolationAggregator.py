#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class InterpolationAggregator(Aggregator):
    name = None
    align_sampling = None 
    sampling = None 

    def __init__(self, align_sampling=True, sampling=None):
        self.name = 'interpolation'
        self.align_sampling = copy(align_sampling)
        self.sampling = copy(sampling)

    def with_align_sampling(self, align_sampling):
        self.align_sampling = align_sampling
        return self

    def with_sampling(self, sampling):
        self.sampling = sampling
        return self

