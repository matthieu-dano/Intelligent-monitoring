#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy
from enum import Enum

class Time_Align(Enum):
     ALIGN_START_TIME='align_start_time'
     ALIGN_END_TIME='align_end_time'
     ALIGN_SAMPLING='align_sampling'
     NO_ALIGN='no_align'

class Interpolation_Method(Enum):
     LINEAR_INTERPOLATION='linear_interpolation'
     LAST_KNOWN_VALUE='last_known_value'
     NEAREST_TIMESTAMP_VALUE='nearest_timestamp_value'
     AVERAGE='average'


class ResampleAggregator(Aggregator):
    name = None
    time_align = None 
    interpolation_method = None 
    sampling = None 

    def __init__(self, time_align=Time_Align.ALIGN_SAMPLING, interpolation_method=Interpolation_Method.LINEAR_INTERPOLATION, sampling=None):
        self.name = 'resample'
        self.time_align = copy(time_align)
        self.interpolation_method = copy(interpolation_method)
        self.sampling = copy(sampling)

    def with_time_align(self, time_align):
        self.time_align = time_align
        return self

    def with_interpolation_method(self, interpolation_method):
        self.interpolation_method = interpolation_method
        return self

    def with_sampling(self, sampling):
        self.sampling = sampling
        return self

