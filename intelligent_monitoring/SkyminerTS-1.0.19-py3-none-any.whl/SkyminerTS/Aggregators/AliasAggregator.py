#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy


class AliasAggregator(Aggregator):
    name = None
    alias = None 

    def __init__(self, alias=None):
        self.name = 'alias'
        self.alias = copy(alias)

    def with_alias(self, alias):
        self.alias = alias
        return self

