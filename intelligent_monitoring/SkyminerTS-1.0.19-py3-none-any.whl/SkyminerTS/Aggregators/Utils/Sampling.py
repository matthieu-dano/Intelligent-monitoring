#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Utils import Generic, check_instance, TimeUnit


class Sampling(Generic):
    value = None
    unit = None

    def __init__(self, value, unit):
        self.value = value
        check_instance(unit, TimeUnit)
        self.unit = unit.value
