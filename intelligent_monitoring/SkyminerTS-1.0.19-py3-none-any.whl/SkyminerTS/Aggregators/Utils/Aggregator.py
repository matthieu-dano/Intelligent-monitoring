#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Utils import Generic


class Aggregator(Generic):
    name = None

    def __init__(self, name):
        self.name = name

    def init(self):
        return self
