#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy
from enum import Enum

class Trim(Enum):
     FIRST='first'
     LAST='last'
     BOTH='both'


class TrimAggregator(Aggregator):
    name = None
    trim = None 

    def __init__(self, trim=Trim.BOTH):
        self.name = 'trim'
        self.trim = copy(trim)

    def with_trim(self, trim):
        self.trim = trim
        return self

