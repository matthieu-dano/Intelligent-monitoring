#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Generated at 21-01-2021 16:44:05
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Aggregators.Utils.Aggregator import Aggregator
from copy import copy
from enum import Enum

class Unit(Enum):
     MILLISECONDS='milliseconds'
     SECONDS='seconds'
     MINUTES='minutes'
     HOURS='hours'
     DAYS='days'
     WEEKS='weeks'
     MONTHS='months'
     YEARS='years'


class SamplerAggregator(Aggregator):
    name = None
    unit = None 

    def __init__(self, unit=Unit.MILLISECONDS):
        self.name = 'sampler'
        self.unit = copy(unit)

    def with_unit(self, unit):
        self.unit = unit
        return self

