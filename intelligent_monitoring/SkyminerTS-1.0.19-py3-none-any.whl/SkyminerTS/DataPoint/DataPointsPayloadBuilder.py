#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from SkyminerTS.Utils import GenericBuilder
from copy import copy
from SkyminerTS.Utils import check_instance


class DataPointsPayloadBuilder(GenericBuilder):
    """
    Constructs the payload of the DataPoints

    :param list[DataPointBuilder] data: List of DatapointBuilder, optional, default: []

    """

    def __init__(self, data=[]):
        self.data = []
        check_instance(data, list)
        self.add_builders(data)

    def add_builder(self, data):
        """
        Add a DataPointBuilder in the payload

        :param DataPointBuilder data: DataPointBuilder
        :return: The instance of the DataPointsPayloadBuilder
        :rtype: DataPointsPayloadBuilder
        """
        self.data.append(data.build())
        return self

    def add_builders(self, datas):
        """
        Add multiple DataPointBuilders in the payload

        :param list[DataPointBuilder] datas: List of DataPointBuilder
        :return: The instance of the DataPointsPayloadBuilder
        :rtype: DataPointsPayloadBuilder
        """
        self.data.extend([data.build() for data in datas])
        return self

    def build(self):
        """
        Build the payload

        :return: The payload
        :rtype: str
        """
        return '[%s]' % (', '.join(self.data))
