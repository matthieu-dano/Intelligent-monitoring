#!/usr/bin/python3
# -*- coding: utf-8 -*-
__author__ = 'Author Jean-Christophe Lan-Yan-Fock'
from copy import copy
from numbers import Number

from SkyminerTS.Utils import GenericBuilder
from SkyminerTS.Utils import check_instance


class DataPointBuilder(GenericBuilder):
    """
    This class facilitates the construction of a Skyminer Datapoint. The instance of this class must be passed to the
    DataPointPayloadBuiler class to format the DataPoint for the Skyminer server.

    Example:
    DataPointBuilder("test_metric_name", datapoints=[[1609943236511, 12],[1609943236511, 15]], tags={"sensor": "temperature"})

    :param str name: name of the timeserie, optional, default: None
    :param [[int, number]] datapoints: List of points [timestamp epoch millis, value], optional, default: []
    :param dict[str,str] tags: Dictionnary of tags, {tag_name: value}, optional, default: dict()
    :param str type: Type of the timeserie, optional, default: None
    :param int ttl: Time to live of the data, optional, default: None
    """
    def __init__(self, name=None, datapoints=[], tags={}, type=None, ttl=None):

        self.name = copy(name)
        check_instance(datapoints, list)
        self.datapoints = copy(datapoints)
        self.tags = copy(tags)
        self.type = copy(type)
        self.ttl = copy(ttl)

    def with_name(self, name):
        """
        Assign a name to the timeserie

        :param str name: Name of the timeserie
        :return: The instance of the builder
        :rtype: DataPointBuilder
        """
        self.name = name
        return self

    def with_points(self, datapoints):
        """
        Add multiple points to the timeserie

        :param [[int, number]] datapoints: List of lists [[timestamp epoch millis, value], ...]
        :return: The instance of the builder
        :rtype: DataPointBuilder
        """
        self.datapoints.extend(datapoints)
        return self

    def with_point(self, timestamp, value):
        """
        Add a point to the timeserie

        :param int timestamp: Timestamp of the point in epoch millis
        :param number value: Value of the point
        :return: The instance of the builder
        :rtype: DataPointBuilder
        """
        self.datapoints.append(point(timestamp, value))
        return self

    def with_tags(self, tags):
        """
        Add tags to the timeserie

        :param dict[str,str] tags: Dictionnary of tags {tag_name: value}
        :return: The instance of the builder
        :rtype: DataPointBuilder
        """
        self.tags = dict(self.tags, **tags)
        return self

    def with_tag(self, key, value):
        """
        Add a tag to the timeserie

        :param str key: Name of the tag, type is str
        :param str value: Value of the tag, type is str
        :return: The instance of the builder
        :rtype: DataPointBuilder
        """
        self.tags[key] = value
        return self

    def with_type(self, type):
        """
        Add the type of the timeserie

        :param str type: Type of the timeserie
        :return: The instance of the builder
        :rtype: DataPointBuilder
        """
        self.type = type
        return self

    def with_ttl(self, ttl):
        """
        Add a ttl to the timeserie

        :param int ttl: TTL of the timeserie
        :return: The instance of the builder
        :rtype: DataPointBuilder
        """
        self.ttl = ttl
        return self


def point(timestamp, value):
    """
    Function that constructs a point for the timeserie

    :param int timestamp: Timestamp of the point in epoch millis
    :param number value: Value of the point
    :return: The point
    :rtype: [int, number]
    """
    return [timestamp, value]
