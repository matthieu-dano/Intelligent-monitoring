import matplotlib.pyplot as plt
import pandas as pd
from SkyminerTSPlot import DataframePlot
from SkyminerTS import MetricToDataframe
import time


class MetricsPlot:

    metrics = None

    def __init__(self, metrics, server_url, filters = {}):

        self.metrics = metrics
        self.server_url = server_url
        self.filters = filters

        # Set default config values
        self._config = {}
        self.config()

        # Initialize matplotlib
        pd.plotting.register_matplotlib_converters()

    def config(self, plot_width=14, plot_height=8.6, start_time=-1, end_time=-1):
        if end_time == -1:
            end_time = int(time.time() * 1000)
        if start_time == -1:
            start_time = end_time - 3600000
        self._config.update({"plot_width": plot_width, "plot_height": plot_height, "start_time": start_time, "end_time": end_time})
        return self

    def show(self):
        for metric in self.metrics:
            self.plot_metric(start=self._config["start_time"], end=self._config["end_time"], **metric)
            plt.show()

    def plot_metric(self, metric, start, end, filters={}, y_low=None, y_high=None, r_low=None, r_high=None, alias=None):
        merged_filters = {**self.filters, **filters}
        dataframe = MetricToDataframe(self.server_url, metric, start, end, merged_filters, alias)
        DataframePlot(dataframe).config(plot_height=self._config["plot_height"], plot_width=self._config["plot_width"]).line().limit(y_low, y_high, r_low, r_high).show()
