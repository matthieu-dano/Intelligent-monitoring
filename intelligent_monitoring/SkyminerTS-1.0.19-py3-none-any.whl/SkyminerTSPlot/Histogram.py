from SkyminerTSPlot.AbstractPlotDataframeBuilder import AbstractPlotBuilder
import numpy as np


class Histogram(AbstractPlotBuilder):

    def __init__(self, plt, dataframe, config):
        super(Histogram, self).__init__(plt, dataframe, config)

    def show(self):
        colors = self.plt.rcParams['axes.prop_cycle'].by_key()['color']
        color_index = 0

        # One plot for each series
        for label, df in self.dataframe.groupby('seriesname'):
            if self.config["one_chart_per_group"]:
                self.plt.figure(df['seriesname'][0])
            n, bins, patches = self.plt.hist(df['value'], 20,  color=colors[color_index % len(colors)], density=1, alpha=0.75)
            color_index += 1
            # Compute the line of best fit
            mu = np.mean(df['value'])
            sigma = np.std(df['value'])
            y = ((1 / (np.sqrt(2 * np.pi) * sigma)) * np.exp(-0.5 * (1 / sigma * (bins - mu)) ** 2))
            # Add the line to the plot
            self.plt.plot(bins, y, 'r--')
            self.plt.title(df['seriesname'][0])
        self.plt.show()
