import matplotlib.pyplot as plt
import pandas as pd
from SkyminerTSPlot.LinePlot import LinePlot
from SkyminerTSPlot.Histogram import Histogram


class DataframePlot:

    dataframe = None

    def __init__(self, dataframe):

        self.dataframe = dataframe
        self._config = {"one_chart_per_group": False}

        # Set default config values
        self.config()

        # Compute series name
        if 'group_by' in self.dataframe:
            self.dataframe['seriesname'] = [str(x) + str(y) if str(y) != "nan" else str(x)
                                            for x, y in zip(self.dataframe['metricname'], self.dataframe['group_by'])]
        else:
            self.dataframe['seriesname'] = self.dataframe['metricname']

        # Initialize matplotlib
        pd.plotting.register_matplotlib_converters()

    def config(self, plot_width=14, plot_height=8.6):
        self._config.update({"plot_width": plot_width, "plot_height": plot_height})
        plt.rcParams['figure.figsize'] = [plot_width, plot_height]
        return self

    def one_chart_per_group(self):
        self._config["one_chart_per_group"] = True
        return self

    def line(self):
        self._config["marker"] = '-'
        return LinePlot(plt, self.dataframe, self._config)

    def scatter(self):
        self._config["marker"] = '.'
        return LinePlot(plt, self.dataframe, self._config)

    def histogram(self):
        self._config["one_chart_per_group"] = True
        return Histogram(plt, self.dataframe, self._config)

    def show(self):
        plt.show()
