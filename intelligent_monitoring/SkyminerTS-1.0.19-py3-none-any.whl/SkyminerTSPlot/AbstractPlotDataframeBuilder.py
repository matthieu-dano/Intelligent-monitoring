class AbstractPlotBuilder:

    def __init__(self, plt, dataframe, config):
        self.plt = plt
        self.dataframe = dataframe
        self.config = config

    def show(self):
        pass
