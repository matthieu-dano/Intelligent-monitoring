from SkyminerTSPlot.AbstractPlotDataframeBuilder import AbstractPlotBuilder


class AbstractPlotWithLimits(AbstractPlotBuilder):

    def __init__(self, plt, dataframe, config):
        super(AbstractPlotWithLimits, self).__init__(plt, dataframe, config)
        self.limit()

    def limit(self, y_low=None, y_high=None, r_low=None, r_high=None):
        self.y_low = y_low
        self.y_high = y_high
        self.r_low = r_low
        self.r_high = r_high
        return self

    def draw_limit(self, name, value, color):
        new_dataframe = self.dataframe.copy()
        new_dataframe[name] = value
        self.plt.plot(new_dataframe.timestamp, new_dataframe[name], linewidth=1, c=color)

    def show(self):
        if self.y_low is not None:
            self.draw_limit("y_low", self.y_low, "orange")
        if self.y_high is not None:
            self.draw_limit("y_high", self.y_high, "orange")
        if self.r_low is not None:
            self.draw_limit("r_low", self.r_low, "red")
        if self.r_high is not None:
            self.draw_limit("r_high", self.r_high, "red")
