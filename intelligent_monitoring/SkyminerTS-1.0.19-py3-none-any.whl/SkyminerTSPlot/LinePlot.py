from SkyminerTSPlot.AbstractPlotDataframeWithLimits import AbstractPlotWithLimits


class LinePlot(AbstractPlotWithLimits):

    def __init__(self, plt, dataframe, config):
        super(LinePlot, self).__init__(plt, dataframe, config)

    def show(self):
        colors = self.plt.rcParams['axes.prop_cycle'].by_key()['color']
        color_index = 0
        for label, df in self.dataframe.groupby('seriesname'):
            if self.config["one_chart_per_group"]:
                self.plt.figure(df['seriesname'][0])

            super().show()
            self.plt.plot(df.timestamp, df.value, self.config["marker"], label=df['seriesname'][0], c=colors[color_index % len(colors)])
            color_index += 1
            self.plt.legend(bbox_to_anchor=(0.5, - 0.15), loc='upper center', ncol=1)
            self.plt.ylabel('Value')
            self.plt.title(df['seriesname'][0], fontweight="bold", fontsize=20)
            self.plt.grid(True)

            if self.config["one_chart_per_group"]:
                self.plt.show()
                self.plt.close()

        if not self.config["one_chart_per_group"]:
            self.plt.show()
            self.plt.close()
